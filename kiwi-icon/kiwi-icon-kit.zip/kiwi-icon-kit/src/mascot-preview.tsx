import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import './fonts/montserrat.css';
import { KiwiLoader, KiwiMascot, KiwiStamp, KIWIMASCOT_STATES, KIWI_STATE_META, KIWI_FRAME_ANIMATIONS, kiwiSceneDrawings } from './components/KiwiMascot/index.ts';
import { IconLibrary } from './components/KiwiIcons/IconLibrary';
import './mascot-preview.css';

type State = (typeof KIWIMASCOT_STATES)[number];
type Motion = 'auto' | 'reduced' | 'paused';

const stateCopy: Record<State, { title: string; detail: string; zhTitle: string; zhDetail: string }> = {
  idle: { title: 'Quiet company', detail: 'A gentle breath, an occasional blink. Ready whenever you are.', zhTitle: '安静陪伴', zhDetail: '轻轻呼吸，偶尔眨眼。准备好时，随时开口。' },
  thinking: { title: 'Thinking', detail: 'A slow turn, a little pause, then back to you.', zhTitle: '认真思考', zhDetail: '慢慢转向，停一停，再回到你面前。' },
  listening: { title: 'Listening', detail: 'Leaning into the moment, taking in what you have to say.', zhTitle: '我在听', zhDetail: '身体微微向前，认真接住你的每一句话。' },
  speaking: { title: 'Speaking', detail: 'A small nod alongside words that are actually arriving.', zhTitle: '正在回答', zhDetail: '轻轻点头，与逐渐出现的文字一起回应。' },
  walk: { title: 'Small steps', detail: 'Short legs, steady steps. Finding a rhythm of its own.', zhTitle: '迈出一步', zhDetail: '短短的腿，一步一步走出自己的节奏。' },
  hop: { title: 'Little hop', detail: 'Crouch, lift off, land. A little curiosity goes a little further.', zhTitle: '小小跳跃', zhDetail: '蹲下、起跳、落地。把好奇心向前送一点。' },
  fly: { title: 'Trying to fly', detail: 'Tiny wings, plenty of resolve. One more attempt.', zhTitle: '试着飞翔', zhDetail: '虽然飞不高，还是想认真扇一扇翅膀。' },
  success: { title: 'Made it', detail: 'One small celebration, saved for a real completion.', zhTitle: '做到了', zhDetail: '一次小小的庆祝，留给真正完成的时刻。' },
  error: { title: 'A quiet pause', detail: 'A lowered head and a pause. Keep a clear way to retry nearby.', zhTitle: '稍等一下', zhDetail: '低一低头，停下来。给用户一个清楚的恢复入口。' },
  offline: { title: 'Waiting to reconnect', detail: 'Patient company while the connection finds its way back.', zhTitle: '暂时断线', zhDetail: '安静等待重新连接，不把失败装成完成。' },
  sleep: { title: 'Dozing', detail: 'Eyes gently close, rest for a while, then slowly open again.', zhTitle: '打个盹', zhDetail: '眼睛渐渐合上，安静停留，再慢慢醒来。' },
  wave: { title: 'Hello there', detail: 'One short wing, one warm hello.', zhTitle: '你好呀', zhDetail: '伸出短短的翅膀，和你打一个招呼。' },
  bow: { title: 'Little bow', detail: 'A slow bow to say thank you with a little care.', zhTitle: '谢谢你', zhDetail: '轻轻低头，把谢意说得认真一点。' },
  curious: { title: 'Curious', detail: 'A little turn toward something worth a closer look.', zhTitle: '让我看看', zhDetail: '抬起头，好奇地看看旁边的新发现。' },
  heart: { title: 'Appreciation', detail: 'A quiet gesture of thanks, without interrupting your flow.', zhTitle: '有你真好', zhDetail: '一个克制的小心意，不打断正在做的事。' },
  notification: { title: 'Look over', detail: 'Notice a real update, turn to acknowledge it, then settle back.', zhTitle: '转头回应', zhDetail: '收到提醒，轻轻转头回应，再回到原来的姿态。' },
  peek: { title: 'Peek out', detail: 'A head appears at the edge and stays to meet your gaze.', zhTitle: '偷偷探头', zhDetail: '从边缘探出脑袋，停下来和你对视。' },
  retract: { title: 'Tuck away', detail: 'Back to the corner, giving you a little room to keep going.', zhTitle: '悄悄缩回', zhDetail: '你继续忙，我就在旁边安静等着。' },
  pop: { title: 'Pop out', detail: 'An invitation, a small hop, and back to the conversation.', zhTitle: '跳出来了', zhDetail: '接到邀请，小跳一下，重新回到对话里。' },
};

function ChineseHint({ show, children }: { show: boolean; children: ReactNode }) {
  return show ? <span className="km-zh-hint" lang="zh-CN" aria-hidden="true">{children}</span> : null;
}

function Arrow({ direction = 'right' }: { direction?: 'right' | 'down' }) {
  return <svg className={`km-arrow km-arrow--${direction}`} viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function CameraGuides({ cellSize }: { cellSize: number }) {
  return <div className="km-camera-guides" aria-hidden="true"><span className="km-camera-origin">0, 0</span><span className="km-camera-centerline"><i>X {cellSize / 2}</i></span><span className="km-camera-baseline"><i>Y {Math.round(cellSize * 0.90625)}</i></span><span className="km-camera-end">{cellSize}, {cellSize}</span></div>;
}

function Preview() {
  const [showChineseHints, setShowChineseHints] = useState(false);
  const [state, setState] = useState<State>('thinking');
  const [motion, setMotion] = useState<Motion>('auto');
  const [replay, setReplay] = useState(0);
  const [inspectFrames, setInspectFrames] = useState(false);
  const [frameIndex, setFrameIndex] = useState(0);
  const [showGuides, setShowGuides] = useState(false);
  const [compareFrames, setCompareFrames] = useState(false);
  const [referenceFrame, setReferenceFrame] = useState(0);
  const [progress, setProgress] = useState(56);
  const [determinate, setDeterminate] = useState(false);
  const [loaderReplay, setLoaderReplay] = useState(0);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatState, setChatState] = useState<State>('idle');
  const [copyState, setCopyState] = useState('Copy code');
  const closeChatRef = useRef<HTMLButtonElement>(null);
  const stampHostRef = useRef<HTMLDivElement>(null);
  const copyTimerRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const path = `${import.meta.env.BASE_URL}kiwi-mascot/`;
  const code = `import { KiwiMascot } from './components/KiwiMascot';\n\n<KiwiMascot state="thinking" variant="portrait" size={48} />`;
  const meta = KIWI_STATE_META[state];
  const animation = KIWI_FRAME_ANIMATIONS[state];
  const drawings = kiwiSceneDrawings(state);
  const selectedFrame = Math.min(frameIndex, drawings.length - 1);
  const atlasCount = new Set(Object.values(KIWI_FRAME_ANIMATIONS).map(item => item.atlas)).size;

  function showFrame(index: number) { setInspectFrames(true); setFrameIndex(Math.min(drawings.length - 1, Math.max(0, index))); }
  function replayAction() { setInspectFrames(false); setCompareFrames(false); setFrameIndex(0); setReplay(value => value + 1); }
  useEffect(() => () => clearTimeout(copyTimerRef.current), []);
  useEffect(() => { if (chatOpen) closeChatRef.current?.focus(); }, [chatOpen]);
  function openChat() { setChatOpen(true); setChatState('wave'); }
  function closeChat() { setChatOpen(false); stampHostRef.current?.querySelector<HTMLButtonElement>('button')?.focus(); }
  async function copyCode() {
    try { await navigator.clipboard.writeText(code); setCopyState('Copied'); }
    catch { setCopyState('Select the code to copy'); }
    clearTimeout(copyTimerRef.current);
    copyTimerRef.current = setTimeout(() => setCopyState('Copy code'), 2200);
  }

  return <div className="km-preview">
    <header className="km-header">
      <a className="km-brand" href="#top" aria-label="Kiwi motion and icon library home"><KiwiMascot variant="icon" size={34} motion="reduced" /><span>kiwi<span className="km-brand-dot">.</span></span></a>
      <nav aria-label="Preview navigation"><a href="#motion">Motion</a><a href="#icons">Icons</a><a href="#stamp">Interact</a><a href="#integration">Use it</a></nav>
      <div className="km-header-right"><span className="km-header-note">ICON & MOTION / 01</span><label className="km-language-toggle"><input type="checkbox" aria-label="Show Chinese hints" checked={showChineseHints} onChange={event => setShowChineseHints(event.target.checked)} /><span>Chinese hints</span></label></div>
    </header>
    <main id="top">
      <section className="km-hero" aria-labelledby="km-hero-title">
        <div className="km-hero-copy"><p className="km-eyebrow"><span className="km-tiny-dot" /> A SMALL COMPANION, ALWAYS HERE.</p><h1 id="km-hero-title">Little Kiwi.<br />Always nearby<span className="km-period">.</span></h1><ChineseHint show={showChineseHints}>小小 Kiwi，陪你走远一点。</ChineseHint><p className="km-lead">A long beak. A pair of tiny wings.<br />A little curious, a little clumsy. Always good company.</p><a className="km-primary-link" href="#motion">Meet every little moment <Arrow /></a><p className="km-hero-footnote">Drawn frames<span>·</span>Interactive preview<span>·</span>Ready for React</p></div>
        <div className="km-hero-art" aria-label="Motion studies based on the selected P2 icon and P3 portrait"><span className="km-orbit km-orbit-one" aria-hidden="true" /><span className="km-orbit km-orbit-two" aria-hidden="true" /><div className="km-hero-icon"><KiwiMascot variant="icon" size={220} state="idle" motion={motion} /></div><div className="km-hero-portrait"><KiwiMascot variant="portrait" size={186} style={{ width: '100%', height: '100%' }} framing="circle" state="curious" motion={motion} /></div><span className="km-art-caption km-art-caption-icon">02 / THE ICON</span><span className="km-art-caption km-art-caption-portrait">03 / THE COMPANION</span><span className="km-hero-plus" aria-hidden="true">+</span></div>
      </section>

      <section className="km-studio km-section" id="motion" aria-labelledby="km-motion-title">
        <div className="km-section-header"><div><p className="km-eyebrow">01 / THE LITTLE MOMENTS</p><h2 id="km-motion-title">A response for every moment.</h2><ChineseHint show={showChineseHints}>每个瞬间，都有回应。</ChineseHint></div><div className="km-motion-controls" aria-label="Motion mode for all examples"><button type="button" aria-pressed={motion === 'auto'} onClick={() => setMotion('auto')}>Play</button><button type="button" aria-pressed={motion === 'paused'} onClick={() => setMotion('paused')}>Pause</button><button type="button" aria-pressed={motion === 'reduced'} onClick={() => setMotion('reduced')}>Less motion</button></div></div>
        <div className="km-studio-grid">
          <div className="km-stage"><div className="km-stage-top"><span>{showGuides ? 'SOURCE CANVAS' : 'CIRCLE PREVIEW'}</span><span>{String(KIWIMASCOT_STATES.indexOf(state) + 1).padStart(2, '0')} / {KIWIMASCOT_STATES.length}</span></div><div className="km-stage-art"><div className="km-camera km-camera--stage" data-camera={showGuides ? 'source-canvas' : 'circle-fit'}><KiwiMascot key={`${state}-${replay}`} state={state} variant={animation.variant} frame={inspectFrames ? drawings[selectedFrame] : undefined} size={240} style={{ width: '100%', height: '100%' }} framing={showGuides ? 'source' : 'circle'} motion={motion} />{showGuides && <CameraGuides cellSize={animation.cellSize} />}</div></div>
            <div className="km-stage-bottom"><div><h3>{stateCopy[state].title}</h3><p>{stateCopy[state].detail}</p><ChineseHint show={showChineseHints}>{stateCopy[state].zhDetail}</ChineseHint></div><button className="km-replay" type="button" onClick={replayAction} aria-label={`Replay ${stateCopy[state].title}`} title="Replay"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 10a8 8 0 1 1 1 7M4 4v6h6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg></button></div>
            <div className="km-stage-spec"><code>{state}</code><span>{animation.frameCount} atlas drawings · {animation.fps} Hz clock · {(meta.durationMs / 1000).toFixed(2)} s {meta.loop ? 'loop' : 'once'}</span></div>
            <div className="km-frame-inspector" aria-label="Inspect individual drawn frames"><div className="km-frame-bar"><button type="button" className="km-frame-mode" aria-pressed={inspectFrames} onClick={() => { setInspectFrames(value => !value); if (inspectFrames) setCompareFrames(false); }}>Inspect frames</button><output htmlFor="km-frame-slider">{inspectFrames ? `Frame ${selectedFrame} / ${drawings.length - 1}` : 'Auto play'}</output><div className="km-frame-steps"><button type="button" aria-label="Previous frame" disabled={inspectFrames && selectedFrame === 0} onClick={() => showFrame(selectedFrame - 1)}>←</button><button type="button" aria-label="Next frame" disabled={inspectFrames && selectedFrame === drawings.length - 1} onClick={() => showFrame(selectedFrame + 1)}>→</button></div></div>
              <input id="km-frame-slider" type="range" min={0} max={drawings.length - 1} step={1} value={selectedFrame} aria-label="Choose animation frame" aria-valuetext={`Frame ${selectedFrame} of ${drawings.length - 1}, source cell ${drawings[selectedFrame]}`} onChange={event => showFrame(Number(event.target.value))} />
              <div className="km-camera-controls"><button type="button" aria-pressed={showGuides} onClick={() => setShowGuides(value => !value)}>Source canvas & guides</button><button type="button" aria-pressed={compareFrames} onClick={() => { setCompareFrames(value => !value); setInspectFrames(true); }}>Compare frames</button>{compareFrames && <button type="button" onClick={() => setReferenceFrame(selectedFrame)}>Pin current frame</button>}</div>
              {compareFrames && <div className="km-frame-comparison" aria-label="Compare two frames in a fixed camera">{[{ name: 'Pinned frame', index: Math.min(referenceFrame, drawings.length - 1) }, { name: 'Current frame', index: selectedFrame }].map(item => <figure key={item.name}><figcaption>{item.name}<code>{String(item.index).padStart(2, '0')}</code></figcaption><div className="km-camera km-camera--comparison" data-camera="fixed-frame" data-comparison-frame={drawings[item.index]}><KiwiMascot state={state} variant={animation.variant} frame={drawings[item.index]} size={160} style={{ width: '100%', height: '100%' }} motion="reduced" />{showGuides && <CameraGuides cellSize={animation.cellSize} />}</div></figure>)}<p>Original source canvases, same size. The pinned frame stays put.</p></div>}
              <div key={state} className="km-frame-strip" aria-label="Drawings in playback order">{drawings.map((cell, index) => <button type="button" key={`${state}-${index}`} aria-label={`View frame ${index}`} title={`Source cell ${cell}`} aria-pressed={inspectFrames && selectedFrame === index} onClick={() => showFrame(index)}><KiwiMascot state={state} variant={animation.variant} frame={cell} size={40} motion="reduced" /><span>{String(index).padStart(2, '0')}</span></button>)}</div>
            </div>
          </div>
          <div className="km-state-library"><div className="km-state-grid" aria-label="Choose a Kiwi action">{KIWIMASCOT_STATES.map(item => <button type="button" key={item} className="km-state-choice" aria-label={stateCopy[item].title} aria-pressed={state === item} onClick={() => { setState(item); setFrameIndex(0); setReferenceFrame(0); setReplay(value => value + 1); }}><KiwiMascot state={item} variant={KIWI_FRAME_ANIMATIONS[item].variant} size={54} frame={KIWI_FRAME_ANIMATIONS[item].sequence[0]} motion="reduced" /><span>{stateCopy[item].title}</span><ChineseHint show={showChineseHints}>{stateCopy[item].zhTitle}</ChineseHint><code>{item}</code></button>)}</div><p className="km-library-note">{atlasCount} drawn sequences · {KIWIMASCOT_STATES.length} scene clips</p><p className="km-frame-caption">Cards show the starting pose. Frame 0 starts each action; drawings follow playback order, with holds omitted. Source canvas & guides shows the original framing.</p><ChineseHint show={showChineseHints}>卡片显示起始姿态；第 0 帧对应动作起点，逐帧按播放顺序排列（省略停留）。原始画布模式保留源坐标。</ChineseHint></div>
        </div>
      </section>

      <section className="km-icons-section km-section" id="icons" aria-labelledby="km-icons-title"><div className="km-section-header"><div><p className="km-eyebrow">02 / THE QUIET SHAPES</p><h2 id="km-icons-title">A face for every little space.</h2><ChineseHint show={showChineseHints}>熟悉的形象，放进每一个小小空间。</ChineseHint></div><p className="km-section-aside">Static identities and interface icons.<br />Made to sit beside the motion.</p></div><IconLibrary showChineseHints={showChineseHints} /></section>

      <section className="km-loader-section" aria-labelledby="km-loader-title"><div className="km-loader-copy"><p className="km-eyebrow">03 / SMALL STEPS, BIG PROGRESS</p><h2 id="km-loader-title">One more step.<br />One more try.</h2><ChineseHint show={showChineseHints}>一步一步，再试着飞起来。</ChineseHint><p>Walk a little. Hop a little.<br />At the end, give those tiny wings a try.</p><span className="km-loader-caption">A loading story with a beginning, a journey, and a return.</span></div><div className="km-loader-demo"><div className="km-loader-surface"><KiwiLoader key={loaderReplay} progress={determinate ? progress / 100 : undefined} width={420} motion={motion} label={determinate ? `Preparing course materials · ${progress}%` : 'Preparing course materials'} /></div><div className="km-loader-controls"><label className="km-toggle"><input type="checkbox" checked={determinate} onChange={event => setDeterminate(event.target.checked)} /><span>Try real progress</span></label><button type="button" onClick={() => setLoaderReplay(value => value + 1)}>Start again <Arrow /></button></div><label className="km-progress-label" htmlFor="km-progress">{determinate ? 'Drag to inspect a progress value' : 'A looping journey for an unknown wait'}<span>{determinate ? `${progress}%` : 'INDETERMINATE'}</span></label><input id="km-progress" aria-label="Demo loading progress" type="range" min="0" max="100" value={progress} disabled={!determinate} onChange={event => setProgress(Number(event.target.value))} /><p className="km-demo-note">This demo uses the slider. In your app, supply actual task progress.</p></div></section>

      <section className="km-stamp-section km-section" id="stamp" aria-labelledby="km-stamp-title"><div className="km-stamp-copy"><p className="km-eyebrow">04 / HELLO FROM THE EDGE</p><h2 id="km-stamp-title">You look over.<br />Kiwi looks back.</h2><ChineseHint show={showChineseHints}>你看它，它也在看你。</ChineseHint><p>Keep a little Kiwi in the corner when chat is tucked away. Hover to peek, leave to retreat, and click or press Enter to come back.</p><div className="km-stamp-hints"><span>Hover / hello</span><span>Click / return</span><span>Leave / wait</span></div><p className="km-fineprint">A collapsed-chat control inside the page. Native Dock and tray behavior needs a desktop host.</p></div><div className="km-desktop"><div className="km-desktop-top"><div className="km-window-dots" aria-hidden="true"><i /><i /><i /></div><span>YOUR QUIET WORKSPACE</span></div><div className="km-desktop-body"><span className="km-desktop-watermark" aria-hidden="true">kiwi.</span><p className="km-desktop-instruction">A little room<br />for your next curious thought.</p>{chatOpen && <section className="km-mock-chat" aria-labelledby="km-chat-title" onKeyDown={event => { if (event.key === 'Escape') closeChat(); }}><header><div><KiwiMascot state={chatState} variant="portrait" size={38} motion={motion} /><div><h3 id="km-chat-title">Kiwi</h3><span>Local interaction demo</span></div></div><button type="button" ref={closeChatRef} onClick={closeChat} aria-label="Collapse Kiwi chat">−</button></header><div className="km-chat-message">{chatState === 'thinking' ? 'Let me think about a good place to start.' : chatState === 'success' ? 'That step is complete. A small pause, then onward.' : chatState === 'error' ? 'That step did not finish. You can try again; I’m here.' : 'Hello again. What would you like to explore today?'}</div><div className="km-chat-actions"><button type="button" onClick={() => setChatState('thinking')}>Think</button><button type="button" onClick={() => setChatState('success')}>Complete</button><button type="button" onClick={() => setChatState('error')}>Error</button></div></section>}<div className="km-stamp-dock" ref={stampHostRef}><KiwiStamp size={92} motion={motion} label="Open Kiwi chat" onActivate={openChat} /><span>{chatOpen ? 'Use − to tuck it away' : 'Come a little closer'}</span></div></div></div></section>

      <section className="km-scale-section km-section" aria-labelledby="km-scale-title"><div className="km-section-header"><div><p className="km-eyebrow">05 / AT HOME, EVERYWHERE</p><h2 id="km-scale-title">Small avatar. Familiar company.</h2><ChineseHint show={showChineseHints}>小到头像，大到陪伴。</ChineseHint></div><p className="km-section-aside">One character, three compositions.<br />The same little personality, light or dark.</p></div><div className="km-scale-layout"><div className="km-size-row">{[24, 32, 48, 96].map(size => <div key={size}><KiwiMascot variant="portrait" size={size} state="idle" motion={motion} /><code>{size} px</code></div>)}</div><div className="km-dark-sample"><KiwiMascot variant="portrait" state="listening" size={88} framing="circle" motion={motion} /><div><span>I’m listening.</span><p>For your next little idea.</p></div></div></div></section>

      <section className="km-integration-section km-section" id="integration" aria-labelledby="km-integration-title"><div className="km-section-header"><div><p className="km-eyebrow">06 / MADE TO MOVE WITH YOU</p><h2 id="km-integration-title">Your interface, its next home.</h2><ChineseHint show={showChineseHints}>下一步，放进你的界面。</ChineseHint></div><span className="km-file-note">src/components/KiwiMascot</span></div><div className="km-code-block"><div><span>REACT / TYPESCRIPT</span><button type="button" onClick={copyCode}>{copyState}</button></div><pre><code>{code}</code></pre></div><div className="km-downloads"><p>Drawn-frame assets<span>PNG atlases and the full asset manifest.</span></p><a href={`${path}frames-v3/portrait-turn.png`} download="kiwi-portrait-turn.png">Turn atlas <Arrow direction="down" /></a><a href={`${path}frames-v3/full-walk.png`} download="kiwi-full-walk.png">Walk atlas <Arrow direction="down" /></a><a href={`${path}frames-v3/manifest.json`} download="kiwi-frames-manifest.json">Manifest <Arrow direction="down" /></a></div><div className="km-doc-downloads"><a href={`${import.meta.env.BASE_URL}README.md`} download="kiwi-README.md">English guide <Arrow direction="down" /></a><a href={`${import.meta.env.BASE_URL}README.zh-CN.md`} download="kiwi-README.zh-CN.md">Chinese guide <Arrow direction="down" /></a><a href={'https://akutagawa1998.github.io/kiwi-icon/kiwi-icon-kit.zip'} download="kiwi-icon-kit.zip">Full frontend kit <Arrow direction="down" /></a></div><p className="km-readme-note">React components, frame timing, static icons, and accessibility: all documented in the downloadable guides.</p></section>
    </main>
    <footer className="km-footer"><span>kiwi. <span>A LITTLE CURIOUS. A LITTLE BRAVE.</span></span><a href="#top">Back to top ↑</a></footer>
  </div>;
}

const previewRoot = createRoot(document.getElementById('root')!);
previewRoot.render(<Preview />);
if (import.meta.hot) import.meta.hot.dispose(() => previewRoot.unmount());

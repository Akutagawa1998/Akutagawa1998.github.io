/**
 * Kiwi's original, intentionally small interface glyph set.
 *
 * Render these children inside a 24×24 SVG with fill="none",
 * stroke="currentColor", stroke-width="2", and round line caps/joins.
 * Keep labels outside the geometry so callers can choose decorative or
 * accessible semantics without rewriting the drawing.
 *
 * @typedef {'communication'|'content'|'tools'|'status'|'controls'} IconCategory
 * @typedef {{label: string, chinese: string, category: IconCategory, paths: string}} FeatureIcon
 */

/** @satisfies {Record<string, FeatureIcon>} */
export const FEATURE_ICONS = {
  chat: {
    label: 'Chat', chinese: '聊天', category: 'communication',
    paths: '<path d="M7 4.5h10a3.5 3.5 0 0 1 3.5 3.5v6a3.5 3.5 0 0 1-3.5 3.5h-5.5L6 21v-3.6A3.5 3.5 0 0 1 3.5 14V8A3.5 3.5 0 0 1 7 4.5Z"/><path d="M8 9h8M8 13h5"/>',
  },
  thinking: {
    label: 'Thinking', chinese: '思考', category: 'communication',
    paths: '<path d="M7.4 15.5A5.6 5.6 0 0 1 4 10.3a5.7 5.7 0 0 1 8-5.2 5.1 5.1 0 0 1 7.5 4.4 4.8 4.8 0 0 1-4.8 4.8H11"/><circle cx="8.5" cy="18" r="1.5"/><path d="M4 21h.01M9 9.5h.01M13 9.5h.01M17 9.5h.01"/>',
  },
  send: {
    label: 'Send', chinese: '发送', category: 'communication',
    paths: '<path d="m3.5 5 17-2-6 18-4.2-8.2L3.5 5Z"/><path d="m10.3 12.8 10.2-9.8"/>',
  },
  attach: {
    label: 'Attach', chinese: '附件', category: 'communication',
    paths: '<path d="m8.5 16.5 7-7a2.2 2.2 0 0 0-3.1-3.1l-8 8a4.4 4.4 0 0 0 6.2 6.2l9-9a6 6 0 0 0-8.5-8.5l-7.5 7.5"/>',
  },
  document: {
    label: 'Document', chinese: '文档', category: 'content',
    paths: '<path d="M7 3.5h7l4.5 4.5v10.5a2 2 0 0 1-2 2h-10a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2Z"/><path d="M14 3.5V8h4.5M8.5 12h6M8.5 16h4"/>',
  },
  folder: {
    label: 'Folder', chinese: '文件夹', category: 'content',
    paths: '<path d="M3.5 8V6a2 2 0 0 1 2-2h4l2 3h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2V8Z"/><path d="M3.5 10h17"/>',
  },
  search: {
    label: 'Search', chinese: '搜索', category: 'tools',
    paths: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.1 15.1 5.4 5.4"/>',
  },
  settings: {
    label: 'Settings', chinese: '设置', category: 'tools',
    paths: '<path d="M3.5 6.5h4M11.5 6.5h9M3.5 12h9M16.5 12h4M3.5 17.5h4M11.5 17.5h9"/><circle cx="9.5" cy="6.5" r="2"/><circle cx="14.5" cy="12" r="2"/><circle cx="9.5" cy="17.5" r="2"/>',
  },
  code: {
    label: 'Code', chinese: '代码', category: 'content',
    paths: '<path d="m7.5 7-5 5 5 5M16.5 7l5 5-5 5M14 4.5l-4 15"/>',
  },
  book: {
    label: 'Book', chinese: '书籍', category: 'content',
    paths: '<path d="M12 6.5C9 4.5 5.7 4 2.5 4.5v14c3.2-.5 6.5 0 9.5 2 3-2 6.3-2.5 9.5-2v-14C18.3 4 15 4.5 12 6.5Z"/><path d="M12 6.5v14M6 9h2.5M15.5 9H18"/>',
  },
  course: {
    label: 'Course', chinese: '课程', category: 'content',
    paths: '<path d="m2.5 8.5 9.5-5 9.5 5-9.5 5-9.5-5Z"/><path d="M6 10.5V17c3.5 2.7 8.5 2.7 12 0v-6.5M21.5 8.5v8"/>',
  },
  progress: {
    label: 'Progress', chinese: '进度', category: 'status',
    paths: '<path d="M20 10.5a8 8 0 1 1-6.5-6.3M18 3.5h3v3"/><path d="m8 15 4-4 3 2 6-9.5"/>',
  },
  check: {
    label: 'Check', chinese: '确认', category: 'status',
    paths: '<path d="m4.5 12.5 5 5 10-11"/>',
  },
  warning: {
    label: 'Warning', chinese: '警告', category: 'status',
    paths: '<path d="m10.3 4.5-7.8 14A1.7 1.7 0 0 0 4 21h16a1.7 1.7 0 0 0 1.5-2.5l-7.8-14a1.9 1.9 0 0 0-3.4 0Z"/><path d="M12 9v5M12 17.5h.01"/>',
  },
  error: {
    label: 'Error', chinese: '错误', category: 'status',
    paths: '<circle cx="12" cy="12" r="8.5"/><path d="m9 9 6 6M15 9l-6 6"/>',
  },
  offline: {
    label: 'Offline', chinese: '离线', category: 'status',
    paths: '<path d="M4 7.5a13 13 0 0 1 16 0M7 11a8 8 0 0 1 10 0M10 14.5a3 3 0 0 1 4 0M12 18h.01M3 3l18 18"/>',
  },
  notification: {
    label: 'Notification', chinese: '通知', category: 'communication',
    paths: '<path d="M6.5 10a5.5 5.5 0 0 1 11 0v4l2 3h-15l2-3v-4Z"/><path d="M10 20a2.2 2.2 0 0 0 4 0M12 3V2"/>',
  },
  play: {
    label: 'Play', chinese: '播放', category: 'controls',
    paths: '<path d="m7 4.5 13 7.5-13 7.5v-15Z"/>',
  },
  pause: {
    label: 'Pause', chinese: '暂停', category: 'controls',
    paths: '<rect x="5" y="4.5" width="4" height="15" rx="1.5"/><rect x="15" y="4.5" width="4" height="15" rx="1.5"/>',
  },
  download: {
    label: 'Download', chinese: '下载', category: 'controls',
    paths: '<path d="M12 3v12M7.5 10.5 12 15l4.5-4.5M4 15.5V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3.5"/>',
  },
  minimize: {
    label: 'Minimize', chinese: '最小化', category: 'controls',
    paths: '<path d="M5 18.5h14"/>',
  },
  expand: {
    label: 'Expand', chinese: '展开', category: 'controls',
    paths: '<path d="M8.5 3.5h-5v5M15.5 3.5h5v5M3.5 15.5v5h5M20.5 15.5v5h-5"/>',
  },
  success: {
    label: 'Success', chinese: '成功', category: 'status',
    paths: '<circle cx="12" cy="12" r="8.5"/><path d="m7.5 12 3 3 6-6"/>',
  },
  help: {
    label: 'Help', chinese: '帮助', category: 'tools',
    paths: '<circle cx="12" cy="12" r="8.5"/><path d="M9.5 8.5a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4M12 16h.01"/>',
  },
};

import { useEffect, useMemo, useState } from 'react';
import { KiwiIcon, type KiwiIconName } from './KiwiIcon';
import './kiwi-icons.css';

const CATEGORIES = {
  brand: 'Brand', mascot: 'Kiwi poses', communication: 'Communication', content: 'Learning content',
  tools: 'Tools', status: 'Status', controls: 'Controls',
} as const;

type IconCategory = keyof typeof CATEGORIES;
type Background = 'cream' | 'sage' | 'dark' | 'transparent';

export interface KiwiIconItem {
  id: string;
  label: string;
  chinese: string;
  category: IconCategory;
  format: 'svg' | 'png';
  /** Deployment-base-relative path, supplied by the generated local manifest. */
  src: string;
  featureName?: KiwiIconName;
}

export interface IconLibraryProps {
  showChineseHints?: boolean;
}

const BACKGROUNDS: Record<Background, { label: string; fill?: string; ink: string }> = {
  cream: { label: 'Cream', fill: '#f5f4e8', ink: '#234631' },
  sage: { label: 'Sage', fill: '#dce5cc', ink: '#234631' },
  dark: { label: 'Forest', fill: '#234631', ink: '#f5f4e8' },
  transparent: { label: 'Transparent', ink: '#234631' },
};
const assetUrl = (path: string) => `${import.meta.env.BASE_URL}${path}`;

function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  // Allow the browser to consume the URL before releasing it.
  const release = URL.revokeObjectURL.bind(URL);
  window.setTimeout(() => release(url), 1000);
}

async function downloadSvgPng(item: KiwiIconItem, background: Background) {
  const response = await fetch(assetUrl(item.src));
  if (!response.ok) throw new Error('SVG unavailable');
  const parsed = new DOMParser().parseFromString(await response.text(), 'image/svg+xml');
  const svg = parsed.documentElement;
  if (svg.localName !== 'svg' || parsed.querySelector('parsererror')) throw new Error('Invalid SVG');
  svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  svg.setAttribute('width', '256');
  svg.setAttribute('height', '256');
  if (item.featureName) svg.setAttribute('color', BACKGROUNDS[background].ink);
  const source = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)], { type: 'image/svg+xml' }));
  try {
    const image = new Image();
    await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error('SVG render failed')); image.src = source; });
    const canvas = globalThis.document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas unavailable');
    const fill = BACKGROUNDS[background].fill;
    if (fill) { context.fillStyle = fill; context.fillRect(0, 0, 256, 256); }
    context.drawImage(image, 0, 0, 256, 256);
    const png = await new Promise<Blob>((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('PNG export failed')), 'image/png'));
    downloadBlob(png, `${item.id}-256.png`);
  } finally { URL.revokeObjectURL(source); }
}

function IconDrawing({ item, size }: { item: KiwiIconItem; size: number }) {
  return item.featureName ? <KiwiIcon name={item.featureName} size={size} decorative /> :
    <img src={assetUrl(item.src)} width={size} height={size} alt="" loading="lazy" />;
}

export function IconLibrary({ showChineseHints = false }: IconLibraryProps) {
  const [items, setItems] = useState<KiwiIconItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<IconCategory | 'all'>('all');
  const [size, setSize] = useState(48);
  const [background, setBackground] = useState<Background>('cream');
  const [selectedId, setSelectedId] = useState('');
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState('');

  useEffect(() => {
    const controller = new AbortController();
    let alive = true;
    fetch(assetUrl('kiwi-icons/manifest.json'), { signal: controller.signal })
      .then(async response => { if (!response.ok) throw new Error('Manifest unavailable'); return response.json(); })
      .then(manifest => {
        if (!Array.isArray(manifest.items)) throw new Error('Invalid manifest');
        if (alive) setItems(manifest.items);
      })
      .catch(() => { if (alive) setError('The icon kit is unavailable. Run the icon export script and refresh this page.'); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; controller.abort(); };
  }, []);

  const visible = useMemo(() => {
    const term = query.trim().toLocaleLowerCase();
    return items.filter(item => (category === 'all' || item.category === category) &&
      (!term || `${item.label} ${item.chinese} ${item.id} ${CATEGORIES[item.category]}`.toLocaleLowerCase().includes(term)));
  }, [items, query, category]);
  const selected = visible.find(item => item.id === selectedId) ?? visible[0];

  return (
    <div className="kiwi-icon-library" data-background={background}>
      <header className="kiwi-icon-library-header">
        <div><h2>Icon library</h2><p>Brand marks, Kiwi poses, and a matching set of product symbols.</p>
          {showChineseHints && <p className="kiwi-icon-chinese">品牌图标、Kiwi 静态姿态与配套功能图标。</p>}</div>
        <a className="kiwi-icon-kit-link" href={assetUrl('kiwi-icons/kiwi-icon-kit.zip')} download>
          <KiwiIcon name="download" size={18} decorative /> Download kit .zip
        </a>
      </header>
      <div className="kiwi-icon-toolbar">
        <label className="kiwi-icon-search"><span>Search icons</span><input type="search" value={query}
          onChange={event => setQuery(event.target.value)} placeholder="Search names or meanings" /></label>
        <label><span>Category</span><select value={category} onChange={event => setCategory(event.target.value as IconCategory | 'all')}>
          <option value="all">All categories</option>
          {Object.entries(CATEGORIES).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
        </select></label>
        <label><span>Icon size</span><select value={size} onChange={event => setSize(Number(event.target.value))}>
          {[16, 24, 32, 48, 64, 96].map(value => <option key={value} value={value}>{value} px</option>)}
        </select></label>
      </div>
      <fieldset className="kiwi-icon-backgrounds"><legend>Preview background</legend>
        {(Object.entries(BACKGROUNDS) as [Background, typeof BACKGROUNDS[Background]][]).map(([key, value]) =>
          <button key={key} type="button" aria-pressed={background === key} onClick={() => setBackground(key)}>{value.label}</button>)}
      </fieldset>
      {loading ? <p role="status">Loading icon kit…</p> : error ? <p role="alert">{error}</p> : <>
        <p className="kiwi-icon-results" role="status">{visible.length} of {items.length} icons</p>
        <div className="kiwi-icon-library-body">
          <div className="kiwi-icon-grid" aria-label="Available icons">
            {visible.map(item => <button key={item.id} type="button" className="kiwi-icon-card"
              aria-label={`Preview ${item.label} (${item.format.toUpperCase()})`} aria-pressed={selected?.id === item.id}
              onClick={() => { setSelectedId(item.id); setExportError(''); }}>
              <span className="kiwi-icon-card-stage"><IconDrawing item={item} size={size} /></span>
              <span className="kiwi-icon-card-name">{item.label}</span>
              {showChineseHints && <span className="kiwi-icon-chinese">{item.chinese}</span>}
              <span className="kiwi-icon-format">{item.format.toUpperCase()}</span>
            </button>)}
            {visible.length === 0 && <p className="kiwi-icon-empty">No icons match. Try another search or category.</p>}
          </div>
          {selected && <aside className="kiwi-icon-detail" aria-label="Selected icon">
            <div className="kiwi-icon-detail-stage"><IconDrawing item={selected} size={Math.max(size * 2, 96)} /></div>
            <h3>{selected.label}</h3>
            {showChineseHints && <p className="kiwi-icon-chinese">{selected.chinese}</p>}
            <dl><div><dt>Category</dt><dd>{CATEGORIES[selected.category]}</dd></div>
              <div><dt>Format</dt><dd>{selected.format.toUpperCase()}</dd></div></dl>
            <div className="kiwi-icon-downloads">
              <a href={assetUrl(selected.src)} download={`${selected.id}.${selected.format}`}>
                <KiwiIcon name="download" size={16} decorative /> Download {selected.format.toUpperCase()}
              </a>
              {selected.format === 'svg' && <button type="button" disabled={exporting} onClick={async () => {
                setExporting(true); setExportError('');
                try { await downloadSvgPng(selected, background); }
                catch { setExportError('PNG export failed. You can still download the original SVG.'); }
                finally { setExporting(false); }
              }}>{exporting ? 'Exporting…' : 'Download PNG · 256 px'}</button>}
            </div>
            {exportError && <p className="kiwi-icon-export-error" role="alert">{exportError}</p>}
            <p className="kiwi-icon-detail-note">{selected.featureName ? 'Product SVG symbols follow currentColor.' : 'Kiwi artwork keeps its original forest, cream, and tan palette.'}
              {selected.format === 'svg' && ' PNG exports use the selected preview background.'}</p>
            {!selected.featureName && background === 'dark' && <p className="kiwi-icon-detail-note">Place Kiwi artwork on a cream badge when using dark surfaces.
              {showChineseHints && <span className="kiwi-icon-chinese"> 深色背景请给 Kiwi 图案配奶油色底牌。</span>}</p>}
          </aside>}
        </div>
      </>}
    </div>
  );
}

import { useId, type SVGProps } from 'react';
import { FEATURE_ICONS } from './iconData.mjs';

export type KiwiIconName = keyof typeof FEATURE_ICONS;

export interface KiwiIconProps extends Omit<SVGProps<SVGSVGElement>, 'name' | 'children' | 'title'> {
  name: KiwiIconName;
  size?: number;
  title?: string;
  /** Defaults to decorative unless a title is supplied. */
  decorative?: boolean;
}

/** Cohesive native product symbols; color follows the surrounding currentColor. */
export function KiwiIcon({ name, size = 24, title, decorative, className = '', ...props }: KiwiIconProps) {
  const titleId = useId();
  const hidden = decorative ?? !title;
  const label = title ?? FEATURE_ICONS[name].label;
  return (
    <svg {...props} className={`kiwi-product-icon ${className}`} viewBox="0 0 24 24"
      width={size} height={size} fill="none" stroke="currentColor" strokeWidth={2}
      strokeLinecap="round" strokeLinejoin="round" focusable="false"
      role={hidden ? undefined : 'img'} aria-hidden={hidden ? true : undefined}
      aria-labelledby={hidden ? undefined : titleId}>
      {!hidden && <title id={titleId}>{label}</title>}
      {/* The child markup is local, authored icon geometry, never user HTML. */}
      <g dangerouslySetInnerHTML={{ __html: FEATURE_ICONS[name].paths }} />
    </svg>
  );
}

import type { CSSProperties } from 'react';

export interface KiwiCircleFraming {
  /** Union center in the registered 256 × 256 source camera. */
  centerX: number;
  centerY: number;
  /** Farthest corner of any alpha-positive pixel across all 24 drawings. */
  radius: number;
  /** Constant source-canvas scale; leaves at least 8% of the circle radius. */
  scale: number;
}

/**
 * Presentation framing for circular badges, never animation compensation.
 * Generated from all alpha > 0 pixel corners in the registered v3 PNG atlases.
 * Each atlas uses one center and scale for every frame, including manual frames.
 * Raw camera inspection must bypass this table.
 * Reproduce: python3 artifacts/kiwi-framing-2026-10-14/verify-circle-fit.py
 */
export const KIWI_CIRCLE_FRAMING: Readonly<Record<string, KiwiCircleFraming>> = {
  'full-hop-flight': { centerX: 146.5, centerY: 126, radius: 141.87406387356359, scale: 0.83003190847445 },
  'full-walk': { centerX: 146, centerY: 150, radius: 133.843191832831, scale: 0.8798355627014727 },
  'full-wave-bow': { centerX: 151, centerY: 157.5, radius: 126.92615963622313, scale: 0.9277835265599006 },
  'portrait-blink': { centerX: 127, centerY: 140.5, radius: 149.7706580075016, scale: 0.7862688297336701 },
  'portrait-doze': { centerX: 125.5, centerY: 145, radius: 138.79211072679888, scale: 0.8484632115135211 },
  'portrait-nod-sleep': { centerX: 131, centerY: 142.5, radius: 141.81061314302255, scale: 0.8304032920387532 },
  'portrait-turn': { centerX: 125.5, centerY: 139, radius: 144.31302782493339, scale: 0.8160039448611324 },
  'stamp-peek': { centerX: 150, centerY: 150, radius: 109.12378292562992, scale: 1 },
};

// A missing atlas still fits its entire source square safely inside the circle.
const FALLBACK: KiwiCircleFraming = {
  centerX: 128, centerY: 128, radius: 128 * Math.SQRT2, scale: 0.92 / Math.SQRT2,
};

/** Place an absolutely positioned source canvas in a circular wrapper.
 * Percentage geometry keeps the same framing at any badge size. No transform,
 * transition, current-frame measurement, or image-pixel mutation is involved.
 */
export function kiwiCircleFrameStyle(atlas: string): Pick<CSSProperties, 'left' | 'top' | 'width' | 'height'> {
  const framing = KIWI_CIRCLE_FRAMING[atlas] ?? FALLBACK;
  const size = framing.scale * 100;
  return {
    left: `${50 - framing.centerX / 256 * size}%`,
    top: `${50 - framing.centerY / 256 * size}%`,
    width: `${size}%`,
    height: `${size}%`,
  };
}

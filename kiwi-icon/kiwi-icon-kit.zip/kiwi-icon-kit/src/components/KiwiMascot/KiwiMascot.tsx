import { useEffect, useLayoutEffect, useMemo, useRef, type CSSProperties } from 'react';
import { KIWI_FRAME_ANIMATIONS, kiwiAtlasUrl, preloadKiwiFrames } from './frames';
import type { KiwiMotion, KiwiState, KiwiVariant } from './states';
import { useKiwiMotion } from './useMotion';
import { useFrameAnimation } from './useFrameAnimation';
import { kiwiCircleFrameStyle } from './framing';
import './kiwi-mascot.css';

export interface KiwiMascotProps {
  state?: KiwiState;
  variant?: KiwiVariant;
  size?: number;
  motion?: KiwiMotion;
  decorative?: boolean;
  label?: string;
  className?: string;
  style?: CSSProperties;
  /** Inspect a drawing index (0..23); overrides automatic playback. */
  frame?: number;
  /** Fixed atlas-wide framing inside a circular surface; source canvas by default. */
  framing?: 'source' | 'circle';
  /** Finite actions complete once; loops never fire. Replay with key. */
  onAnimationComplete?: () => void;
}

export function KiwiMascot({ state = 'idle', variant = 'portrait', size = 48,
  motion = 'auto', decorative = true, label = 'Kiwi', className = '', style, frame, framing = 'source',
  onAnimationComplete }: KiwiMascotProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const { reduced, paused } = useKiwiMotion(motion, ref);
  const animation = KIWI_FRAME_ANIMATIONS[state];
  const lastDrawn = useRef<{ state: KiwiState; atlas: string; cell: number; manual: boolean } | null>(null);
  const sequence = useMemo(() => {
    const previous = lastDrawn.current;
    const reversesPeek = (state === 'peek' && previous?.state === 'retract') ||
      (state === 'retract' && previous?.state === 'peek');
    if (frame === undefined && previous && !previous.manual && reversesPeek && previous.atlas === animation.atlas) {
      // Reverse/continue from the drawing the user actually saw. Preserve the
      // destination timeline's order and repeated-cell holds, rather than
      // assuming numbered cells are adjacent or that every atlas starts at 0.
      const start = animation.sequence.indexOf(previous.cell);
      if (start >= 0) return animation.sequence.slice(start);
    }
    return animation.sequence;
  }, [state, animation.atlas, animation.sequence, frame]);
  const staticIcon = variant === 'icon' && state === 'idle' && frame === undefined;
  const index = useFrameAnimation({ sequence, fps: animation.fps,
    loop: animation.loop, reduced, paused: paused || staticIcon,
    manualFrame: frame === undefined ? undefined : Math.max(0, Math.min(animation.frameCount - 1, Math.trunc(frame))),
    animationId: state, onComplete: onAnimationComplete });
  useLayoutEffect(() => {
    lastDrawn.current = { state, atlas: animation.atlas, cell: index, manual: frame !== undefined };
  }, [state, animation.atlas, index, frame]);
  useEffect(preloadKiwiFrames, []);
  const column = index % animation.columns;
  const row = Math.floor(index / animation.columns);
  return (
    <span ref={ref} className={`kiwi-mascot kiwi-mascot--${variant} kiwi-mascot--${state} kiwi-mascot--${framing} ${className}`}
      data-state={state} data-frame={index} data-atlas={animation.atlas}
      data-framing={framing}
      data-renderer="drawn-frames" data-motion={reduced ? 'reduced' : paused ? 'paused' : 'auto'}
      role={decorative ? undefined : 'img'} aria-label={decorative ? undefined : label}
      aria-hidden={decorative ? true : undefined}
      style={{ width: size, height: size, ...style }}>
      {staticIcon ? <img className="kiwi-static-icon" src={`${import.meta.env.BASE_URL}kiwi-mascot/kiwi-icon.svg`} alt="" /> :
        <span className="kiwi-drawn-frame" style={{
          ...(framing === 'circle' ? kiwiCircleFrameStyle(animation.atlas) : {}),
          backgroundImage: `url("${kiwiAtlasUrl(animation.atlas)}")`,
          backgroundSize: `${animation.columns * 100}% ${animation.rows * 100}%`,
          backgroundPosition: `${column / (animation.columns - 1) * 100}% ${row / (animation.rows - 1) * 100}%`,
        }} />}
    </span>
  );
}

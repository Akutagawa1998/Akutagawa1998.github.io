import type { KiwiState, KiwiVariant } from './states';

const span = (start: number, end: number) => Array.from({ length: Math.abs(end - start) + 1 }, (_, i) => start + i * Math.sign(end - start));
const hold = (frame: number, count: number) => Array<number>(count).fill(frame);
const expose = (frames: number[], ticks = 2) => frames.flatMap(frame => hold(frame, ticks));
const outAndBack = (start: number, end: number, pause = 36, exposure = 3) => [...hold(start, pause), ...expose(span(start, end), exposure), ...hold(end, pause), ...expose(span(end - Math.sign(end - start), start), exposure)];
// Two ticks per actual drawing, with the same short settling exposure at both
// ends. Retract reverses this exact timeline, including its exposure lengths.
const peek = [...hold(0, 4), ...expose(span(0, 23)), ...hold(23, 4)];

export interface KiwiFrameAnimation {
  atlas: string; frameCount: number; columns: number; rows: number; cellSize: number;
  fps: number; loop: boolean; variant: KiwiVariant; sequence: readonly number[];
}
const clip = (atlas: string, variant: KiwiVariant, sequence: number[], loop = true): KiwiFrameAnimation => ({
  atlas, variant, sequence, loop, frameCount: 24, columns: 6, rows: 4, cellSize: 256, fps: 24,
});

/** Registered source drawings on a fixed camera. 24 Hz is the timeline clock;
 * exposures are explicit, so a gentle action need not change art every tick.
 * No crossfading, pose warping, or runtime camera compensation.
 */
export const KIWI_FRAME_ANIMATIONS: Record<KiwiState, KiwiFrameAnimation> = {
  idle: clip('portrait-blink', 'portrait', [...hold(0, 84), ...span(0, 23), ...hold(23, 36), ...expose(span(22, 14)), ...hold(14, 36), ...span(13, 0)]),
  thinking: clip('portrait-turn', 'portrait', outAndBack(0, 23)),
  listening: clip('portrait-turn', 'portrait', outAndBack(23, 18, 48)),
  speaking: clip('portrait-nod-sleep', 'portrait', [...hold(0, 24), ...expose(span(0, 8), 3), ...hold(8, 12), ...expose(span(7, 0), 3), ...hold(0, 36)]),
  walk: clip('full-walk', 'full', expose(span(0, 23))),
  hop: clip('full-hop-flight', 'full', [...expose(span(0, 23), 3), ...hold(23, 12)], false),
  fly: clip('full-hop-flight', 'full', [...expose(span(9, 16), 3), ...hold(16, 6), ...expose(span(15, 9), 3), ...hold(9, 6)]),
  success: clip('full-hop-flight', 'full', [...expose(span(0, 23), 3), ...hold(23, 24)], false),
  error: clip('portrait-nod-sleep', 'portrait', [...expose(span(0, 8), 3), ...hold(8, 36)], false),
  offline: clip('portrait-doze', 'portrait', [...hold(23, 120), ...expose(span(23, 18), 6), ...expose(span(19, 23), 6)]),
  sleep: clip('portrait-doze', 'portrait', [...hold(0, 48), ...expose(span(0, 23), 3), ...hold(23, 144), ...expose(span(22, 0), 3)]),
  wave: clip('full-wave-bow', 'full', [...expose(span(0, 14), 3), ...hold(14, 18)], false),
  bow: clip('full-wave-bow', 'full', [...expose(span(14, 17), 4), ...hold(17, 18), ...expose(span(16, 14), 4), ...hold(14, 18)], false),
  curious: clip('portrait-turn', 'portrait', outAndBack(0, 17, 36)),
  heart: clip('full-wave-bow', 'full', [...expose(span(14, 17), 4), ...hold(17, 30), ...expose(span(16, 14), 4), ...hold(14, 30)], false),
  notification: clip('portrait-turn', 'portrait', [...hold(0, 6), ...expose(span(0, 12), 3), ...hold(12, 18), ...expose(span(11, 0), 3), ...hold(0, 18)], false),
  peek: clip('stamp-peek', 'icon', peek, false),
  retract: clip('stamp-peek', 'icon', [...peek].reverse(), false),
  pop: clip('full-hop-flight', 'full', [...expose(span(0, 23), 2), ...hold(23, 12)], false),
};

/** Drawing changes in playback order. Holds are omitted; return poses remain.
 * An inspection index is not an atlas-cell index (notably for retract).
 */
export function kiwiSceneDrawings(state: KiwiState): number[] {
  return KIWI_FRAME_ANIMATIONS[state].sequence.filter((cell, index, sequence) => index === 0 || cell !== sequence[index - 1]);
}

export function kiwiAtlasUrl(name: string) { return `${import.meta.env.BASE_URL}kiwi-mascot/frames-v3/${name}.webp`; }
let preloaded = false;
export function preloadKiwiFrames() {
  if (preloaded || typeof Image === 'undefined') return;
  preloaded = true;
  for (const name of new Set(Object.values(KIWI_FRAME_ANIMATIONS).map(item => item.atlas))) {
    const image = new Image(); image.src = kiwiAtlasUrl(name);
  }
}

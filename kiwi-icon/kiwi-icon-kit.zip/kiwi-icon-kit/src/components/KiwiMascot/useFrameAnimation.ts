import { useEffect, useRef, useState } from 'react';

export interface FrameAnimationOptions {
  /** Ordered atlas cell indices. Repeating an index holds that drawing longer. */
  sequence: readonly number[];
  fps: number;
  loop: boolean;
  /** Include offscreen state here; document visibility is also handled internally. */
  paused: boolean;
  reduced: boolean;
  /** An actual atlas cell index, independent of its position in sequence. */
  manualFrame?: number;
  /** Changing this or sequence identity interrupts the old action and starts anew. */
  animationId?: string;
  onComplete?: () => void;
}

interface Timeline {
  elapsedMs: number;
  completed: boolean;
}

const atlasCell = (value: number | undefined): number =>
  Number.isFinite(value) ? Math.max(0, Math.trunc(value!)) : 0;

/**
 * Plays whole drawings with no geometric interpolation. Frame positions derive
 * from elapsed time, so dropped rAF callbacks never slow the animation down.
 * Keep sequence identity stable (for example a module constant or useMemo).
 * Pausing and manual inspection preserve both the elapsed time and frame phase.
 * Reduced motion uses the first loop drawing or final finite drawing; a finite
 * action completes on the next task, unless paused/hidden or manually inspected.
 */
export function useFrameAnimation({ sequence, fps, loop, paused, reduced,
  manualFrame, animationId, onComplete }: FrameAnimationOptions): number {
  const rate = Number.isFinite(fps) && fps > 0 ? fps : 24;
  const callback = useRef(onComplete);
  callback.current = onComplete;
  const timeline = useRef<Timeline>({ elapsedMs: 0, completed: false });
  const [hidden, setHidden] = useState(() => typeof document !== 'undefined' && document.hidden);
  const renderedIdentity = useRef({ sequence, animationId });
  const [drawn, setDrawn] = useState(() =>
    atlasCell(sequence[reduced && !loop ? sequence.length - 1 : 0]));

  useEffect(() => {
    const update = () => setHidden(document.hidden);
    document.addEventListener('visibilitychange', update);
    return () => document.removeEventListener('visibilitychange', update);
  }, []);

  // Reset before the playback effect starts its next segment. Callback identity,
  // pause/resume and manual inspection deliberately do not restart the timeline.
  useEffect(() => {
    timeline.current = { elapsedMs: 0, completed: false };
    renderedIdentity.current = { sequence, animationId };
    setDrawn(atlasCell(sequence[reduced && !loop ? sequence.length - 1 : 0]));
  }, [sequence, animationId]);

  useEffect(() => {
    let alive = true;
    let request: number | undefined;
    let completionTask: number | undefined;
    const draw = (cell: number) => setDrawn(cell);

    if (manualFrame !== undefined || sequence.length === 0) return;

    if (reduced) {
      draw(atlasCell(sequence[loop ? 0 : sequence.length - 1]));
      if (!loop && !paused && !hidden && !timeline.current.completed) {
        completionTask = window.setTimeout(() => {
          if (!alive || timeline.current.completed) return;
          timeline.current.completed = true;
          timeline.current.elapsedMs = sequence.length * 1000 / rate;
          callback.current?.();
        }, 0);
      }
      return () => {
        alive = false;
        if (completionTask !== undefined) window.clearTimeout(completionTask);
      };
    }

    if (paused || hidden || (!loop && timeline.current.completed)) return;

    const baseElapsed = timeline.current.elapsedMs;
    const startedAt = performance.now();
    const elapsedAt = (timestamp: number) => baseElapsed + Math.max(0, timestamp - startedAt);
    const tick = (timestamp: number) => {
      if (!alive) return;
      const elapsed = Math.max(timeline.current.elapsedMs, elapsedAt(timestamp));
      timeline.current.elapsedMs = elapsed;
      const position = Math.floor(elapsed * rate / 1000);
      const ended = !loop && position >= sequence.length;
      draw(atlasCell(sequence[ended ? sequence.length - 1 : position % sequence.length]));
      if (ended) {
        timeline.current.completed = true;
        callback.current?.();
        return;
      }
      request = window.requestAnimationFrame(tick);
    };
    request = window.requestAnimationFrame(tick);

    return () => {
      alive = false;
      if (request !== undefined) window.cancelAnimationFrame(request);
      // Include the fraction of the current frame before a pause/interruption.
      // Wall time spent paused is excluded when the next segment starts.
      if (loop || !timeline.current.completed) {
        timeline.current.elapsedMs = Math.max(timeline.current.elapsedMs, elapsedAt(performance.now()));
      }
    };
  }, [sequence, animationId, rate, loop, paused, hidden, reduced, manualFrame]);

  if (manualFrame !== undefined) return atlasCell(manualFrame);
  // An interrupted action cannot render a drawing from the previous sequence
  // while React waits for the reset effect to run.
  if (renderedIdentity.current.sequence !== sequence || renderedIdentity.current.animationId !== animationId) {
    return atlasCell(sequence[reduced && !loop ? sequence.length - 1 : 0]);
  }
  return drawn;
}

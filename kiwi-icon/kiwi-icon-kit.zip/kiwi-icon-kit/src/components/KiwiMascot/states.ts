import { KIWI_FRAME_ANIMATIONS } from './frames';

export const KIWIMASCOT_STATES = [
  'idle', 'thinking', 'listening', 'speaking', 'walk', 'hop', 'fly',
  'success', 'error', 'offline', 'sleep', 'wave', 'bow', 'curious',
  'heart', 'notification', 'peek', 'retract', 'pop',
] as const;

export type KiwiState = typeof KIWIMASCOT_STATES[number];
export type KiwiMotion = 'auto' | 'reduced' | 'paused';
export type KiwiVariant = 'portrait' | 'full' | 'icon';

export const KIWI_STATE_META: Record<KiwiState, {
  label: string; loop: boolean; durationMs: number;
}> = {
  idle: { label: 'Idle', loop: true, durationMs: 4800 },
  thinking: { label: 'Thinking', loop: true, durationMs: 3000 },
  listening: { label: 'Listening', loop: true, durationMs: 3200 },
  speaking: { label: 'Speaking', loop: true, durationMs: 1800 },
  walk: { label: 'Walk', loop: true, durationMs: 640 },
  hop: { label: 'Hop', loop: false, durationMs: 720 },
  fly: { label: 'Fly', loop: true, durationMs: 1600 },
  success: { label: 'Success', loop: false, durationMs: 1000 },
  error: { label: 'Error', loop: false, durationMs: 520 },
  offline: { label: 'Offline', loop: true, durationMs: 4000 },
  sleep: { label: 'Sleep', loop: true, durationMs: 4200 },
  wave: { label: 'Wave', loop: false, durationMs: 1200 },
  bow: { label: 'Bow', loop: false, durationMs: 1100 },
  curious: { label: 'Curious', loop: true, durationMs: 2800 },
  heart: { label: 'Heart', loop: false, durationMs: 1400 },
  notification: { label: 'Notification', loop: false, durationMs: 800 },
  peek: { label: 'Peek', loop: false, durationMs: 280 },
  retract: { label: 'Retract', loop: false, durationMs: 240 },
  pop: { label: 'Pop', loop: false, durationMs: 560 },
};

// Host timers follow the actual frame timeline, including explicit holds.
for (const state of KIWIMASCOT_STATES) {
  const clip = KIWI_FRAME_ANIMATIONS[state];
  KIWI_STATE_META[state].durationMs = clip.sequence.length * 1000 / clip.fps;
  KIWI_STATE_META[state].loop = clip.loop;
}

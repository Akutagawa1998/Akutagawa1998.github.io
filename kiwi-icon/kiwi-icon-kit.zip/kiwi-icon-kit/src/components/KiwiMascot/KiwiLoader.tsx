import { useEffect, useRef, useState } from 'react';
import type { KiwiMotion } from './states';
import { KIWI_FRAME_ANIMATIONS, kiwiAtlasUrl } from './frames';
import { useKiwiMotion } from './useMotion';
import { useFrameAnimation } from './useFrameAnimation';
import './kiwi-mascot.css';

export interface KiwiLoaderProps {
  /** Omit for indeterminate work. Supply real progress only, from 0 to 1. */
  progress?: number;
  label?: string;
  width?: number;
  motion?: KiwiMotion;
}

export interface KiwiJourneyPose {
  atlas: string;
  cell: number;
  x: number;
}

const WALK = KIWI_FRAME_ANIMATIONS.walk;
const HOP = KIWI_FRAME_ANIMATIONS.hop;
const FLY = KIWI_FRAME_ANIMATIONS.fly;
const tickSequence = (length: number) => Array.from({ length }, (_, slot) => slot);
export const KIWI_JOURNEY_TIMING = {
  fps: 24,
  walkInSlots: 96,
  hopSlots: HOP.sequence.length,
  walkOutSlots: 64,
  totalSlots: 96 + HOP.sequence.length + 64,
} as const;
export const KIWI_JOURNEY_DURATION_MS = KIWI_JOURNEY_TIMING.totalSlots * 1000 / KIWI_JOURNEY_TIMING.fps;
const JOURNEY_SEQUENCE = tickSequence(KIWI_JOURNEY_TIMING.totalSlots);
const WALK_TICKS = tickSequence(WALK.sequence.length);
const FLY_TICKS = tickSequence(FLY.sequence.length);
const ATLAS_NAMES = [...new Set([WALK.atlas, HOP.atlas, FLY.atlas])];
const ATLAS_LAYOUTS = Object.fromEntries([WALK, HOP, FLY].map(clip => [clip.atlas, clip]));
const MASCOT_SIZE = 64;
const SCENE_HEIGHT = 80;
// Registered standing feet are at cell y=222: 14.5 + 222 * 64 / 256 = ground y=70.
const SCENE_DRAW_Y = 14.5;

type JourneyImages = Record<KiwiJourneyPose['atlas'], HTMLImageElement>;

const realProgress = (value?: number) =>
  value === undefined || !Number.isFinite(value) ? undefined : Math.min(1, Math.max(0, value));
const deviceRatio = () => typeof window === 'undefined' ? 1 : Math.max(1, window.devicePixelRatio || 1);

/** Whole generated drawings move through the scene; no bird part is transformed. */
export function kiwiJourneyPose(slot: number, width: number, size = MASCOT_SIZE, progress?: number): KiwiJourneyPose {
  const slotIndex = Number.isFinite(slot) ? Math.max(0, Math.trunc(slot)) : 0;
  const end = Math.max(0, width - size);
  const value = realProgress(progress);
  if (value !== undefined) {
    const clip = value === 1 ? FLY : WALK;
    return { atlas: clip.atlas, cell: clip.sequence[slotIndex % clip.sequence.length], x: value * end };
  }
  const frame = slotIndex % KIWI_JOURNEY_TIMING.totalSlots;
  const hopStart = KIWI_JOURNEY_TIMING.walkInSlots;
  const exitStart = hopStart + KIWI_JOURNEY_TIMING.hopSlots;
  if (frame < hopStart) {
    return { atlas: WALK.atlas, cell: WALK.sequence[frame % WALK.sequence.length],
      x: -size + (end + size) * frame / (hopStart - 1) };
  }
  if (frame < exitStart) return { atlas: HOP.atlas, cell: HOP.sequence[frame - hopStart], x: end };
  const exitSlot = frame - exitStart;
  return { atlas: WALK.atlas, cell: WALK.sequence[exitSlot % WALK.sequence.length],
    x: end + (width + size - end) * exitSlot / (KIWI_JOURNEY_TIMING.walkOutSlots - 1) };
}

export function KiwiLoader({ progress, label = 'Kiwi is thinking…', width = 200, motion = 'auto' }: KiwiLoaderProps) {
  const ref = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { reduced, paused } = useKiwiMotion(motion, ref);
  const requestedWidth = Number.isFinite(width) && width > 0 ? width : 200;
  const [sceneWidth, setSceneWidth] = useState(requestedWidth);
  const [ratio, setRatio] = useState(deviceRatio);
  const [images, setImages] = useState<JourneyImages>();
  const [failed, setFailed] = useState(false);
  const lastPosition = useRef(0);
  const value = realProgress(progress);
  const playbackSequence = value === undefined ? JOURNEY_SEQUENCE : value === 1 ? FLY_TICKS : WALK_TICKS;
  const slot = useFrameAnimation({ sequence: playbackSequence, fps: KIWI_JOURNEY_TIMING.fps, loop: true,
    reduced, paused: paused || !images, animationId: 'kiwi-loader-journey' });

  useEffect(() => {
    let alive = true;
    const loaded = new Set<string>();
    const assets: JourneyImages = Object.fromEntries(ATLAS_NAMES.map(name => [name, new Image()]));
    const ready = (name: KiwiJourneyPose['atlas']) => {
      if (!alive) return;
      loaded.add(name);
      if (loaded.size === ATLAS_NAMES.length) setImages(assets);
    };
    for (const name of ATLAS_NAMES) {
      const image = assets[name];
      image.decoding = 'async';
      image.onload = () => ready(name);
      image.onerror = () => { if (alive) setFailed(true); };
      image.src = kiwiAtlasUrl(name);
      if (image.complete && image.naturalWidth > 0) ready(name);
    }
    return () => {
      alive = false;
      for (const image of Object.values(assets)) { image.onload = null; image.onerror = null; }
    };
  }, []);

  useEffect(() => {
    const measure = () => {
      const measured = ref.current?.getBoundingClientRect().width;
      setSceneWidth(measured && measured > 0 ? measured : requestedWidth);
      setRatio(deviceRatio());
    };
    measure();
    window.addEventListener('resize', measure);
    const observer = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(measure);
    if (ref.current) observer?.observe(ref.current);
    return () => { window.removeEventListener('resize', measure); observer?.disconnect(); };
  }, [requestedWidth]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !images) return;
    const context = canvas.getContext('2d');
    if (!context) return;
    const physicalWidth = Math.round(sceneWidth * ratio);
    const physicalHeight = Math.round(SCENE_HEIGHT * ratio);
    if (canvas.width !== physicalWidth) canvas.width = physicalWidth;
    if (canvas.height !== physicalHeight) canvas.height = physicalHeight;
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = 'high';
    context.clearRect(0, 0, sceneWidth, SCENE_HEIGHT);
    context.strokeStyle = getComputedStyle(canvas).getPropertyValue('--kiwi-sage').trim() || '#92ae70';
    context.lineWidth = 1;
    context.beginPath();
    context.moveTo(0, 70);
    context.lineTo(sceneWidth, 70);
    context.stroke();

    const pose = kiwiJourneyPose(slot, sceneWidth, MASCOT_SIZE, value);
    if (reduced) {
      pose.atlas = WALK.atlas;
      pose.cell = WALK.sequence[0];
      // Keep a visible static drawing at the last scene position. Authoritative
      // progress still sets its own position, including when motion is reduced.
      pose.x = value === undefined ? Math.min(Math.max(lastPosition.current, 0), Math.max(0, sceneWidth - MASCOT_SIZE)) : value * Math.max(0, sceneWidth - MASCOT_SIZE);
    } else lastPosition.current = pose.x;
    const atlas = ATLAS_LAYOUTS[pose.atlas];
    const column = pose.cell % atlas.columns;
    const row = Math.floor(pose.cell / atlas.columns);
    context.drawImage(images[pose.atlas], column * atlas.cellSize, row * atlas.cellSize, atlas.cellSize, atlas.cellSize,
      pose.x, SCENE_DRAW_Y, MASCOT_SIZE, MASCOT_SIZE);
  }, [images, slot, sceneWidth, ratio, reduced, value]);

  return (
    <div ref={ref} className={`kiwi-loader ${value === undefined ? 'kiwi-loader--journey' : 'kiwi-loader--progress'}`}
      data-motion={reduced ? 'reduced' : paused ? 'paused' : 'auto'} data-renderer="drawn-frame-scene"
      data-assets={failed ? 'failed' : images ? 'ready' : 'loading'} data-scene-frame={slot}
      style={{ width: requestedWidth }}
      role={value === undefined ? 'status' : 'progressbar'} aria-label={label}
      aria-valuemin={value === undefined ? undefined : 0} aria-valuemax={value === undefined ? undefined : 100}
      aria-valuenow={value === undefined ? undefined : Math.round(value * 100)}>
      <canvas ref={canvasRef} className="kiwi-loader-canvas" width={Math.round(sceneWidth * ratio)}
        height={Math.round(SCENE_HEIGHT * ratio)} aria-hidden="true" />
      <span className="kiwi-loader-label">{label}</span>
    </div>
  );
}

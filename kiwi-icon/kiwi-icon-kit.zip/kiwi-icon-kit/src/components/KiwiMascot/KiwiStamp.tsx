import { useEffect, useRef, useState, type CSSProperties, type PointerEvent } from 'react';
import { KiwiMascot } from './KiwiMascot';
import type { KiwiMotion, KiwiState } from './states';
import { useKiwiMotion } from './useMotion';

export interface KiwiStampProps {
  size?: number;
  motion?: KiwiMotion;
  label?: string;
  onActivate?: () => void;
  disabled?: boolean;
  className?: string;
  style?: CSSProperties;
}

export function KiwiStamp({ size = 64, motion = 'auto', label = 'Open Kiwi Chat',
  onActivate, disabled = false, className = '', style }: KiwiStampProps) {
  const [state, setState] = useState<KiwiState>('idle');
  const hovering = useRef(false);
  const focused = useRef(false);
  const popping = useRef(false);
  const ref = useRef<HTMLButtonElement>(null);
  const { reduced, paused } = useKiwiMotion(motion, ref);
  const [activation, setActivation] = useState(0);
  useEffect(() => {
    if (disabled || (popping.current && (reduced || paused))) {
      popping.current = false;
      setState(disabled ? 'idle' : hovering.current || focused.current ? 'peek' : 'idle');
    }
  }, [disabled, reduced, paused]);
  const enter = () => { if (!popping.current) setState('peek'); };
  const leave = () => {
    if (!popping.current && !hovering.current && !focused.current) setState('retract');
    ref.current?.style.removeProperty('--kiwi-gaze-x');
    ref.current?.style.removeProperty('--kiwi-gaze-y');
  };
  const gaze = (event: PointerEvent<HTMLButtonElement>) => {
    if (event.pointerType === 'touch') return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = Math.max(-2, Math.min(2, (event.clientX - rect.left - rect.width / 2) / rect.width * 4));
    const y = Math.max(-1.5, Math.min(1.5, (event.clientY - rect.top - rect.height / 2) / rect.height * 3));
    ref.current?.style.setProperty('--kiwi-gaze-x', `${x}px`);
    ref.current?.style.setProperty('--kiwi-gaze-y', `${y}px`);
  };
  return (
    <button ref={ref} type="button" className={`kiwi-stamp ${className}`} disabled={disabled}
      aria-label={label} style={{ width: Math.max(44, size), height: Math.max(44, size), ...style }}
      onPointerEnter={(event) => { if (event.pointerType !== 'touch') { hovering.current = true; enter(); } }}
      onPointerMove={gaze} onPointerLeave={() => { hovering.current = false; leave(); }}
      onFocus={() => { focused.current = true; enter(); }}
      onBlur={() => { focused.current = false; leave(); }}
      onClick={() => {
        popping.current = !reduced && !paused;
        setActivation(value => value + 1);
        setState(popping.current ? 'pop' : hovering.current || focused.current ? 'peek' : 'idle');
        // Opening is synchronous. Artwork never delays the host's action.
        onActivate?.();
      }}>
      <KiwiMascot key={activation} variant="icon" state={disabled ? 'idle' : state} size={size} motion={motion}
        onAnimationComplete={() => {
          if (state === 'pop') { popping.current = false; setState(hovering.current || focused.current ? 'peek' : 'idle'); }
          else if (state === 'retract') setState('idle');
        }} />
    </button>
  );
}
